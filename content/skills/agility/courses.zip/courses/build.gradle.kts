plugins { id("org.jetbrains.kotlin.jvm") }
dependencies { compileOnly(projects.engine) }

